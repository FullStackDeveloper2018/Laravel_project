$(document).ready(function () {
    $("#coaching_report_table").DataTable({
        paging: false,
        searching: false,
    });
})
