<?php

namespace App\Http\Controllers\SuperAdmin\Content\SubTools;

use App\Http\Controllers\Controller;
use App\Model\BreathingTool;
use Illuminate\Http\Request;
use Validator;
class BreathingToolController extends Controller
{

    public function index()
    {
        //
    }

    public function store(Request $req)
    {
        $breathing_tool = $req->except('_token');
        $validator = Validator::make($req->all(), [
            'title_in_english' => 'required',
            'title_in_french' => 'required',
            'breathe_in' => 'required',
            'breathe_out' => 'required',
            'hold1' => 'required',
            'hold2' => 'required',
            'challengeusers' => 'required'
        ]);

        if ($validator->passes()) {

            $challenge_user = array_map(function($value) {
                return intval($value);
            }, $req->challengeusers);

            $breathing_tool['user_select'] = json_encode($challenge_user);


            BreathingTool::create($breathing_tool);
            $notification = array(
                'message' => 'Saved successfuly',
                'alert-type' => 'success',
            );

            return back()->with($notification);
        } else {
            $notification = array(
                'message' => 'All fields must be filled',
                'alert-type' => 'error',
            );

            return back()->with($notification);
        }
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        BreathingTool::where('id', $id)->delete();
        $notification = array(
            'message' => 'Breathing Tool deleted successfuly!',
            'alert-type' => 'success',
        );

        return back()->with($notification);
    }
}
