<?php

namespace App\Http\Controllers\SuperAdmin\Content;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SubToolsController extends Controller
{
    //
}
