<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Model\Challenge;
use Illuminate\Http\Request;
use Validator;

class ChallengeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $current_model;
    public function __construct()
    {
        $this->middleware('auth');
        $this->current_model = new Challenge();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $challenges = Challenge::all();

        return view('backend.superadmin.challenge', compact(
            'challenges'
        ));
    }

    // Save coaching report
    public function saveChallenge(Request $req)
    {
        $challenge = $req->except('_token');
        $validator = Validator::make($req->all(), [
            'name_english' => 'required',
            'name_frensh' => 'required',
            'description_english' => 'required',
            'description_frensh' => 'required',
            'icon' => 'required',
            'challengeusers' => 'required',
            'categories' => 'required'
        ]);

        if ($validator->passes()) {

            $frequency = array_map(function($value) {
                return intval($value);
            }, $req->categories);
            $challenge_user = array_map(function($value) {
                return intval($value);
            }, $req->challengeusers);

            $challenge['frequency'] = json_encode($frequency);
            $challenge['challengeuser'] = json_encode($challenge_user);


            Challenge::create($challenge);
            $notification = array(
                'message' => 'Saved successfuly',
                'alert-type' => 'success',
            );

            return back()->with($notification);
        } else {
            $notification = array(
                'message' => 'All fields must be filled',
                'alert-type' => 'error',
            );

            return back()->with($notification);
        }
    }

    public function editChallenge(Request $req, $id)
    {
        $challenge = $req->except('_token');
        $validator = Validator::make($req->all(), [
            'name_english' => 'required',
            'name_frensh' => 'required',
            'description_english' => 'required',
            'description_frensh' => 'required',
            'icon' => 'required',
            'challengeusersEdit' => 'required',
            'categoriesEdit' => 'required'
        ]);
        if ($validator->passes()) {

            $frequency = array_map(function($value) {
                return intval($value);
            }, $req->categoriesEdit);
            $challenge_user = array_map(function($value) {
                return intval($value);
            }, $req->challengeusersEdit);

            $datas['name_english'] = $req->name_english;
            $datas['name_frensh'] = $req->name_frensh;
            $datas['description_english'] = $req->description_english;
            $datas['description_frensh'] = $req->description_frensh;
            $datas['icon'] = $req->icon;
            $datas['challengeuser'] = json_encode($challenge_user);
            $datas['frequency'] = json_encode($frequency);

            Challenge::where('challenge_id', $id)->update($datas);

            $notification = array(
                'message' => 'Edited successfuly',
                'alert-type' => 'success',
            );

            return back()->with($notification);
        } else {
            $notification = array(
                'message' => 'All fields must be filled',
                'alert-type' => 'error',
            );

            return back()->with($notification);
        }
    }

    // Delete Coaching
    public function deleteChallenge($id)
    {
        Challenge::where('challenge_id', $id)->delete();
        $notification = array(
            'message' => 'Delete successfuly',
            'alert-type' => 'success',
        );

        return back()->with($notification);
    }

}
