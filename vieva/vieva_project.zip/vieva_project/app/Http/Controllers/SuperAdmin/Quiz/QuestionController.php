<?php

namespace App\Http\Controllers\SuperAdmin\Quiz;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    //
}
