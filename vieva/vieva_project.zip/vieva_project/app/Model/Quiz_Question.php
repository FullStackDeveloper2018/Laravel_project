<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Quiz_Question extends Model
{
    protected $table = 'vieva_quiz_questions';
}
