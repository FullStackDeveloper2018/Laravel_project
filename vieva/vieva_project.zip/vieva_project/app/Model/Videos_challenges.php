<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Videos_challenges extends Model
{
    //
}
