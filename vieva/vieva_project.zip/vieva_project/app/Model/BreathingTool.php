<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class BreathingTool extends Model
{
    protected $table = 'vieva_breathing_tool';
    protected $guarded = ['id'];
    public $timestamps = false;
}
