<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Corporate_clients_settings extends Model
{
    protected $table = 'vieva_corporate_clients_settings';
    protected $guarded = ['id'];
}
